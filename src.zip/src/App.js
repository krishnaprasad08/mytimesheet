import React, { Component } from 'react';
import './App.css';
import TimeReport from './TimeReport';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      reports: [
        {
          reportId: 0,
          empId: 599480,
          empName: 'Krish',
          periodEndDate: '9/22/2017',
          version: 'original',
          status: 'Pending',
          hours: [8, 9, 7, 8, 9]
        },
       
      ]
    };
    this.updateStatus = this.updateStatus.bind(this);
    this.addReport = this.addReport.bind(this);
    this.updateSwipehours = this.updateSwipehours.bind(this);
  }
  updateStatus(id, status) {
    var reports = this.state.reports;
    reports = reports.map(rep => {
      if (id === rep.reportId) {
        rep.status = status;
      }
      return rep;
    })
    this.setState({
      reports: reports
    })
    //    console.log(id,status);
  }
  addReport(report, hrs) {
    var reports = this.state.reports;
    console.log(report);
    if (report && report.reportId !== null) {
      reports = reports.map(rep => {
        if (rep.reportId === report.reportId) {
          rep.hours = hrs
        }
        return rep;
      })
  
    }
    else {
      var newReport = {
        reportId: this.state.reports.length,
        empId: 599480,
        empName: 'Krish',
        periodEndDate: '9/22/2017',
        version: 'original',
        status: 'Pending',
        hours: hrs
      }
      reports.push(newReport);
      
    }
    this.setState({ reports: reports });
  
  }
  updateSwipehours(report, hours) {
    var reports = this.state.reports;
    reports = reports.map((rep) => {
      if (report.reportId !== null && report.reportId === rep.reportId) {
        rep.hours = hours
      }
      return rep;
    })
    this.setState({
      reports: reports
    })
  }
  render() {
    return (
      <div className="App">
        <TimeReport reports={this.state.reports} updateStatus={this.updateStatus} addReport={this.addReport} updateSwipehours={this.updateSwipehours} />

      </div>
    );
  }
}
export default App;