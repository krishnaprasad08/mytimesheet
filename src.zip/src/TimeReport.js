import React, { Component } from 'react';
import TRCard from './TRCard';
import TRCard1 from './TRCard1';
import './TimeReport.css'
import FullContainer from './container.js';
import Button from './button.js'
class TimeReport extends Component {
    constructor() {
        super();
      this.state={
        formSubmitted : 1,
        selectedReport : null,
      }
this.click1=this.click1.bind(this);
        this.click = this.click.bind(this);
        this.cardExpand = this.cardExpand.bind(this);
        this.addReport= this.addReport.bind(this);
    }
    click() {
        this.setState({
            formSubmitted : 2,
            selectedReport : {
                reportId : null,
                empId : 599444,
                empName : 'Krish',
                periodEndDate : '9/22/2017',
                version : 'original',
                status : 'Pending',
                hours : [0,0,0,0,0]
            }
        });
    }
       
    cardExpand(rep){
        console.log(rep);
        this.setState({
            selectedReport : rep,
            formSubmitted : 2
        });
    }
    addReport(rep,hours){
        this.props.addReport(rep,hours);
        this.setState({formSubmitted:1,selectedReport : null});
    }
    click1(e){
        this.setState({formSubmitted:3});
    }
  render() {
    return (
      <div className="timereport">
        
                       {this.state.formSubmitted === 1 ?  
                       <div>
      <h3 id="heading">Create New Timesheet</h3>
      <h2>Copy from an Existing Time Report</h2>
      <h3 id="Addbutton">KrishnaPrasad</h3>
      <Button innerText="Add" onclick={this.click}/>
      <table>
        <thead>
            <tr>
                <th>Period End Date</th>
                <th>Time Report Id</th>
                <th>Employee Id</th>
                <th>Name</th>
                <th>Status</th>
                <th>version</th>
               
            </tr>
        </thead>
        <tbody>
            {this.props.reports.map((report,i) => 
                <TRCard1 key={i} report={report} cardExpand={this.cardExpand} updateStatus={this.props.updateStatus}/>
            )}
        </tbody>
      </table> 
          <Button innerText="MyApproval" onclick={this.click1}/>
      </div> :  this.state.formSubmitted === 2 ? 

       <FullContainer report={this.state.selectedReport} addReport={this.addReport} updateSwipehours={this.props.updateSwipehours}/> 
       : 
       <table>
        <thead>
            <tr>
                <th>Period End Date</th>
                <th>Time Report Id</th>
                <th>Employee Id</th>
                <th>Name</th>
                <th>Status</th>
                <th>version</th>
                <th>Action</th>
                
            </tr>
            </thead>
            <tbody>


                {this.props.reports.map((report,i) => 
                <TRCard key={i} report={report} cardExpand={this.cardExpand} updateStatus={this.props.updateStatus} />
            )}
                       
                </tbody>
            </table>
       }
      

      
      </div>
    );
  }
}

export default TimeReport;
