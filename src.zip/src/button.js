import React, { Component } from 'react';
import './button.css';
class Button extends Component
{
    render()
    {
        return(
            <span>
            <button onClick={this.props.onclick} >{this.props.innerText}</button>
</span>
        );
    }
}
export default Button;


