import React, { Component } from 'react';
import './textbox.css';
import Text from './text.js';
import Option from './option.js';
class TextBox extends Component {
    render() {
        return (
            <span>
                <span className="Text1">
                    <Text list="krishna" className="a" />
                    <datalist id="krishna">
                        <Option value="1000001345" />
                        <Option value="1000001346" />
                        <Option value="1000001375" />
                        <Option value="1000001385" />
                        <Option value="1000001395" />
                        <Option value="1000001335" />
                    </datalist>

                </span>
             

                <span className="Text6">
                    PayPalRampUp
                </span>
                <span className="Text2">
                    <Text list="hhh" className="c" />
                    <datalist id="hhh">
                        <Option value="Proposal Development" />
                        <Option value="Proposal Review" />
                        <Option value="research" />
                        <Option value="Travel" />
                    </datalist>
                </span>
                <span className="Text3">
                    <Text list="ppp" className="d" />
                    <datalist id="ppp">
                        <Option value="OF" />
                        <Option value="ON" />
                        
                    </datalist>

                </span>
                <span className="Text4">
                    <Text list="mm" className="e" />
                    <datalist id="mm">
                        <Option value="Billable" />
                        <Option value="Non-Billable" />
                       
                    </datalist>

                </span>
                <span className="Text5">
                    <Text list="nn" className="f" />
                    <datalist id="nn">
                        <Option value="DLF" />
                        <Option value="SIRSUSERI" />
                        <Option value="SHOLLINGANALLUR" />
                    </datalist>
                </span>
            </span>
        );

    }
}
export default TextBox;